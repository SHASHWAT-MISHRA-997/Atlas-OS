from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_plan_success_is_simulation_only():
    response = client.post("/api/tasks/plan", json={"command": "Analyze sales"})
    assert response.status_code == 200
    body = response.json()
    assert body["mode"] == "simulation"
    assert len(body["steps"]) == 4
    assert "no files" in body["notice"]

def test_plan_rejects_empty_command():
    response = client.post("/api/tasks/plan", json={"command": ""})
    assert response.status_code == 422

def test_plan_rejects_too_long_command():
    response = client.post("/api/tasks/plan", json={"command": "x" * 2001})
    assert response.status_code == 422
