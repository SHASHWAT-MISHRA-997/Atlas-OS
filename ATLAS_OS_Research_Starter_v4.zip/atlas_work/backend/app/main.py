from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator
from typing import Literal
import httpx

CANDIDATE_ROOT = Path(__file__).resolve().parents[2]
ROOT = CANDIDATE_ROOT if (CANDIDATE_ROOT / "frontend" / "index.html").exists() else Path(__file__).resolve().parents[1]
app = FastAPI(title="ATLAS OS API", version="0.1.0", docs_url="/api/docs")

# Same-origin by default. If frontend/backend are hosted separately, replace this
# with a strict allowlist from environment configuration before production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

class PlanRequest(BaseModel):
    command: str = Field(min_length=1, max_length=2000)

class PlanResponse(BaseModel):
    mode: str
    command: str
    steps: list[str]
    notice: str

# Preset endpoints only: do not accept arbitrary URLs from clients (SSRF protection).
LLM_PROVIDERS = {
    "openai": {"label": "OpenAI", "base_url": "https://api.openai.com/v1", "key_required": True},
    "groq": {"label": "Groq", "base_url": "https://api.groq.com/openai/v1", "key_required": True},
    "openrouter": {"label": "OpenRouter", "base_url": "https://openrouter.ai/api/v1", "key_required": True},
    "nvidia": {"label": "NVIDIA NIM", "base_url": "https://integrate.api.nvidia.com/v1", "key_required": True},
    "together": {"label": "Together AI", "base_url": "https://api.together.xyz/v1", "key_required": True},
    "cerebras": {"label": "Cerebras", "base_url": "https://api.cerebras.ai/v1", "key_required": True},
    "fireworks": {"label": "Fireworks AI", "base_url": "https://api.fireworks.ai/inference/v1", "key_required": True},
    "deepseek": {"label": "DeepSeek", "base_url": "https://api.deepseek.com/v1", "key_required": True},
    "ollama": {"label": "Ollama (local)", "base_url": "http://127.0.0.1:11434/v1", "key_required": False},
}

class LLMChatRequest(BaseModel):
    provider: Literal["openai", "groq", "openrouter", "nvidia", "together", "cerebras", "fireworks", "deepseek", "ollama"]
    model: str = Field(min_length=1, max_length=200)
    api_key: str = Field(default="", max_length=1000)
    prompt: str = Field(min_length=1, max_length=12000)

    @field_validator("model", "prompt")
    @classmethod
    def reject_whitespace_only(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("must not be blank")
        return value.strip()

    @field_validator("api_key")
    @classmethod
    def normalize_api_key(cls, value: str) -> str:
        return value.strip()

class LLMChatResponse(BaseModel):
    provider: str
    model: str
    answer: str

@app.get("/api/llm/providers")
def llm_providers():
    """Provider presets using OpenAI-compatible chat-completions APIs."""
    return {"providers": [{"id": key, "label": value["label"], "key_required": value["key_required"]}
                          for key, value in LLM_PROVIDERS.items()],
            "note": "Model IDs, availability, pricing, and free tiers are provider-controlled and can change."}

@app.post("/api/llm/chat", response_model=LLMChatResponse)
async def llm_chat(body: LLMChatRequest):
    """One-shot BYOK chat. The API key is used for this request only and is not persisted."""
    from fastapi import HTTPException
    provider = LLM_PROVIDERS[body.provider]
    if provider["key_required"] and not body.api_key:
        raise HTTPException(status_code=422, detail="This provider requires an API key.")
    url = provider["base_url"] + "/chat/completions"
    payload = {"model": body.model, "messages": [{"role": "user", "content": body.prompt}], "temperature": 0.2}
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(45.0, connect=10.0), follow_redirects=False) as client:
            response = await client.post(url, headers={**({"Authorization": f"Bearer {body.api_key}"} if body.api_key else {}), "Content-Type": "application/json"}, json=payload)
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Provider timed out. Try again or choose another model.")
    except httpx.RequestError:
        raise HTTPException(status_code=502, detail="Could not reach the model provider. Check provider status and network access.")
    if response.status_code in (401, 403):
        raise HTTPException(status_code=502, detail="Provider rejected the API key or its permissions. Verify the key and account access.")
    if response.status_code == 429:
        raise HTTPException(status_code=429, detail="Provider rate limit or quota reached. Wait, check billing/free-tier limits, or choose another model.")
    if response.status_code >= 400:
        # Do not forward provider response bodies; they may contain sensitive diagnostic details.
        raise HTTPException(status_code=502, detail=f"Provider returned HTTP {response.status_code}. Verify the model ID and provider availability.")
    try:
        data = response.json()
        answer = data["choices"][0]["message"]["content"]
        if not isinstance(answer, str) or not answer.strip():
            raise ValueError("empty content")
    except (ValueError, KeyError, IndexError, TypeError):
        raise HTTPException(status_code=502, detail="Provider response was not in the expected chat-completions format.")
    return LLMChatResponse(provider=body.provider, model=body.model, answer=answer)

@app.get("/health")
def health():
    return {"status": "ok", "service": "atlas-os-api", "mode": "demo"}

@app.post("/api/tasks/plan", response_model=PlanResponse)
def plan_task(body: PlanRequest):
    command = body.command.strip()
    if not command:
        # Handles whitespace-only strings despite min_length validation.
        from fastapi import HTTPException
        raise HTTPException(status_code=422, detail="Command must not be blank.")
    return PlanResponse(
        mode="simulation",
        command=command,
        steps=[
            "Understand goal and constraints",
            "Assign relevant specialist roles",
            "Prepare execution and verification checklist",
            "Request permissions before real external actions",
        ],
        notice="Planning only: no files, commands, or external services were accessed.",
    )

@app.get("/", include_in_schema=False)
def frontend():
    return FileResponse(ROOT / "frontend" / "index.html")
